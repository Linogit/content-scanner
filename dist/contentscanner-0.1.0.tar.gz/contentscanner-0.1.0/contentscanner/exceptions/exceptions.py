class ExceptionUrl(Exception):
    pass


class ExceptionGetResponse(Exception):
    pass


class ExceptionGetWordlist(Exception):
    pass